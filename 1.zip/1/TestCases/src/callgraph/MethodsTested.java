package callgraph;

import java.io.IOException;
import java.sql.SQLException;

public class MethodsTested {
	public static void main(String args[]) 
	{

	}
	
	
}
